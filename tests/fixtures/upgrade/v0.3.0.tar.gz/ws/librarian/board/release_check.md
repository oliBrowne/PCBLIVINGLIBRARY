# Release check - `/tmp/tmphh4zjrhw/ws/librarian/board/plan.json`

5 parts: 1 ready (0 by --allow), 4 held.

| Part | Status | Symbol from | Footprint from | Height | Failures |
|---|---|---|---|---|---|
| CAP-0603-100nF | held | kicad:Device:C |  |  | files: no footprint model (.PcbLib); fields: no datasheet link |
| LM358DR | held | kicad:Amplifier_Operational:LM358 |  |  | files: no footprint model (.PcbLib) |
| NOWHERE1 | held |  |  |  | files: no symbol model (.SchLib); files: no footprint model (.PcbLib); fields: Manufacturer is empty; fields: no datasheet link; fields: Description is empty |
| RES-0603-10k | held | kicad:Device:R |  |  | files: no footprint model (.PcbLib); fields: no datasheet link |
| EEPART1 | pass | easyeda:C2002 | easyeda:C2002 | 1.20 | - |

## Warnings (not held)

- **EEPART1**: warning silk: silkscreen is 0.181 mm from pad 1 (KLC: >= 0.2 mm); no height range for package 'EEPART1'; only checked 0.05-30.0 mm

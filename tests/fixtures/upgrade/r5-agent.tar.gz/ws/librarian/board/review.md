# Librarian review - `/tmp/tmpgln9li3e/ws/uploads/board.csv`

5 parts: 1 ready for Altium 365, 4 held, 5 need a person.

Sources (symbol / footprint): - / -: 1, easyeda / easyeda: 1, kicad / -: 3

| Part | Status | Symbol from | Footprint from |
|---|---|---|---|
| CAP-0603-100nF | held | kicad:Device:C | - |
| LM358DR | held | kicad:Amplifier_Operational:LM358 | - |
| NOWHERE1 | held | - | - |
| RES-0603-10k | held | kicad:Device:R | - |
| EEPART1 | ready | easyeda:C2002 | easyeda:C2002 |

## Needs a person

- **CAP-0603-100nF** (held): no footprint found; kicad: symbol Device:C (generic passive symbol); kicad: failed (OSError: kicad-packages3D/Capacitor_SMD.3dshapes/C_0603_1608Metric.step: offline: not in cache); easyeda: no LCSC number; datasheet: no datasheet URL known; fields: no datasheet link
- **LM358DR** (held): no footprint found; kicad: symbol Amplifier_Operational:LM358 (name + ordering suffix 'DR' (check the variant)); kicad: failed (OSError: kicad-packages3D/Package_SO.3dshapes/SOIC-8_3.9x4.9mm_P1.27mm.step: offline: not in cache); easyeda: no LCSC number; needs datasheet reader (no API key): http://www.ti.com/lit/ds/symlink/lm2904-n.pdf (KiCad symbol Amplifier_Operational:LM358); symbol Amplifier_Operational:LM358 matched by name + ordering suffix 'DR' (check the variant)
- **NOWHERE1** (held): no symbol found; no footprint found; kicad: no symbol named like NOWHERE1; kicad: no footprint for 'NOWHERE1'; easyeda: no LCSC number; datasheet: no datasheet URL known; fields: Manufacturer is empty; fields: no datasheet link; fields: Description is empty
- **RES-0603-10k** (held): no footprint found; kicad: symbol Device:R (generic passive symbol); kicad: failed (OSError: kicad-packages3D/Resistor_SMD.3dshapes/R_0603_1608Metric.step: offline: not in cache); easyeda: no LCSC number; datasheet: no datasheet URL known; fields: no datasheet link
- **EEPART1** (ready): EasyEDA C2002 conversion: check pads and pins against the datasheet (native converter, format assumed)

## What was tried

- **CAP-0603-100nF**: kicad: symbol Device:C (generic passive symbol); kicad: failed (OSError: kicad-packages3D/Capacitor_SMD.3dshapes/C_0603_1608Metric.step: offline: not in cache); easyeda: no LCSC number; datasheet: no datasheet URL known
- **LM358DR**: kicad: symbol Amplifier_Operational:LM358 (name + ordering suffix 'DR' (check the variant)); kicad: failed (OSError: kicad-packages3D/Package_SO.3dshapes/SOIC-8_3.9x4.9mm_P1.27mm.step: offline: not in cache); easyeda: no LCSC number; needs datasheet reader (no API key): http://www.ti.com/lit/ds/symlink/lm2904-n.pdf (KiCad symbol Amplifier_Operational:LM358)
- **NOWHERE1**: kicad: no symbol named like NOWHERE1; kicad: no footprint for 'NOWHERE1'; easyeda: no LCSC number; datasheet: no datasheet URL known
- **RES-0603-10k**: kicad: symbol Device:R (generic passive symbol); kicad: failed (OSError: kicad-packages3D/Resistor_SMD.3dshapes/R_0603_1608Metric.step: offline: not in cache); easyeda: no LCSC number; datasheet: no datasheet URL known
- **EEPART1**: kicad: no symbol named like EEPART1; kicad: no footprint for 'EEPART1'; easyeda C2002: footprint SOT-23-3_L2.9-W1.3-P1.90-LS2.4-BR, symbol

# Release check - `/tmp/tmp9r75tzg8/ws/librarian/board/plan.json`

5 parts: 2 ready (0 by --allow), 3 held.

| Part | Status | Symbol from | Footprint from | Height | Failures |
|---|---|---|---|---|---|
| CAP-0603-100nF | held | kicad:Device:C | standard:Capacitor_SMD:C_0603_1608Metric | 0.80 | fields: no datasheet link |
| LM358DR | pass | kicad:Amplifier_Operational:LM358 | standard:Package_SO:SOIC-8_3.9x4.9mm_P1.27mm | 1.75 | - |
| NOWHERE1 | held |  |  |  | files: no symbol model (.SchLib); files: no footprint model (.PcbLib); fields: Manufacturer is empty; fields: no datasheet link; fields: Description is empty |
| RES-0603-10k | held | kicad:Device:R | standard:Resistor_SMD:R_0603_1608Metric | 0.45 | fields: no datasheet link |
| EEPART1 | pass | easyeda:C2002 | easyeda:C2002 | 1.20 | - |

## Warnings (not held)

- **EEPART1**: warning silk: silkscreen is 0.181 mm from pad 1 (KLC: >= 0.2 mm); no height range for package 'EEPART1'; only checked 0.05-30.0 mm

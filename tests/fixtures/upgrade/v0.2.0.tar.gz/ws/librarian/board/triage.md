# BOM triage - `/tmp/tmp0ofvvzd5/ws/uploads/board.csv`

## Summary

- **unverified (source unreachable)**: 4
- **available_easyeda**: 1

## Header mapping

| field | BOM column |
|---|---|
| designator | Designator |
| qty | Qty |
| value | Value |
| footprint | Footprint |
| manufacturer | Manufacturer |
| mpn | Mfr Part # |
| lcsc | LCSC |
| description | Description |

## Lines

| # | Ref | MPN | LCSC | Pkg | Status | Local symbol | Local footprint | Src sym/fp/3D | Notes |
|---|---|---|---|---|---|---|---|---|---|
| 1 | R1, R2 | RC0603FR-0710KL |  | 0603 | unverified (source unreachable) |  |  | -/-/- | jlcpcb_search: offline: not in cache |
| 2 | C1 | GRM188R71C104KA01D |  | 0603 | unverified (source unreachable) |  |  | -/-/- | jlcpcb_search: offline: not in cache |
| 3 | U2 | LM358DR |  | SOIC8 | unverified (source unreachable) |  |  | -/-/- | jlcpcb_search: offline: not in cache |
| 4 | Q1 | EEPART1 | C2002 |  | available_easyeda |  |  | yes/yes/yes |  |
| 5 | U9 | NOWHERE1 |  |  | unverified (source unreachable) |  |  | -/-/- | jlcpcb_search: offline: not in cache |

## Providers

| provider | configured | auth |
|---|---|---|
| jlcpcb_search | yes | none (anonymous JSON POST; Origin/Referer jlcpcb.com) - as used by easyeda2kicad search |
| easyeda | yes | none (public endpoint used by easyeda2kicad; Referer https://easyeda.com/ header) |

## HTTP (this run)

- `jlcpcb.com`: 4 requests -> ['offline-miss']
- `easyeda.com`: 1 requests -> ['cache 200']
